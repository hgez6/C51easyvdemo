#ifndef __timer0_H__
#define __timer0_H__
void Timer0Init(void);
#endif