#ifndef __16key_H__
#define __16key_H__
unsigned char key16();
#endif
