#ifndef __bz_h_
#define __bz_h_
void bztime(unsigned int ms);
#endif