#ifndef __delay_h_
#define __delay_h_
void delay(unsigned int x);
#endif