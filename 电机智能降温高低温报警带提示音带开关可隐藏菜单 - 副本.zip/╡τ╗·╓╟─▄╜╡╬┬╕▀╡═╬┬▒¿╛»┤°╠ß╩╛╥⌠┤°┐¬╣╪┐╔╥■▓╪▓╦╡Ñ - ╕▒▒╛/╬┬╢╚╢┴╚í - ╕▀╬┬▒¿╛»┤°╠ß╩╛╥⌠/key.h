#ifndef __key_H__
#define __key_H__
unsigned char key();
#endif