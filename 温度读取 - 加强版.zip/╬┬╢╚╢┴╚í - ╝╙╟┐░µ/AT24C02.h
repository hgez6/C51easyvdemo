#ifndef __AT24C02_h_
#define __AT24C02_h_

unsigned char AT24C02_ReadByte(unsigned char WordAddress);
void AT24C02_WriteByte(unsigned char WordAddress,Data);


#endif