#ifndef __DS18B20_h_
#define __DS18B20_h_
void DS18B20_ConvertT(void);
float DS18B20_ReadT();
#endif