#ifndef __key_H__
#define __key_H__
unsigned char key();
void key_loop();
unsigned char key_getstate();

#endif