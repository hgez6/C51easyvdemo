#ifndef __xs_H__
#define __xs_H__
void sx(unsigned char x,y);
void sx_loop();
void set(unsigned loca,num);
#endif